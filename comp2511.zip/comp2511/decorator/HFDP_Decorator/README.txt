/**
 * These example files are from the recommended reference book titled
 * "Design Patterns : Head First" By: Eric Freeman, Elisabeth Robson, 
 *  Bert Bates and Kathy Sierra; Publisher: O'Reilly Media (2004)
 */
 