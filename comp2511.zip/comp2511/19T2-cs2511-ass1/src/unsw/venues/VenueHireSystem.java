/**
 *
 */
package unsw.venues;

import java.time.LocalDate;

import java.util.ArrayList;

import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;




/**
 * Venue Hire System for COMP2511.
 *
 * A basic prototype to serve as the "back-end" of a venue hire system. Input
 * and output is in JSON format.
 *
 * @author Robert Clifton-Everest
 *
 */
public class VenueHireSystem {
	public ArrayList<venue> venueList;
	public ArrayList<room> roomList;
	public ArrayList<booking> bookingList;
    /**
     * Constructs a venue hire system. Initially, the system contains no venues,
     * rooms, or bookings.
     */
    public VenueHireSystem() {
    	this.venueList = new ArrayList<venue>();
    	this.roomList = new ArrayList<room>();
    	this.bookingList = new ArrayList<booking>();
        // TODO Auto-generated constructor stub
    }
    
    public VenueHireSystem(JSONObject venueList) {
    	
    }
    

    private void processCommand(JSONObject json) {
        switch (json.getString("command")) {

        case "room":
            String venue = json.getString("venue");
            String room = json.getString("room");
            String size = json.getString("size");
            addRoom(venue, room, size);
            break;

        case "request":
            String id = json.getString("id");
            LocalDate start = LocalDate.parse(json.getString("start"));
            LocalDate end = LocalDate.parse(json.getString("end"));
            int small = json.getInt("small");
            int medium = json.getInt("medium");
            int large = json.getInt("large");

            JSONObject result = request(id, start, end, small, medium, large);

            System.out.println(result.toString());
            break;
        
        case "change":
        	String idc = json.getString("id");
        	LocalDate startc = LocalDate.parse(json.getString("start"));
        	LocalDate endc = LocalDate.parse(json.getString("end"));
        	int smallc = json.getInt("small");
        	int mediumc = json.getInt("medium");
        	int largec = json.getInt("large");
        	change(idc, startc, endc, smallc, mediumc, largec);


        	break;
        
        case "cancel":
        	String idr = json.getString("id");
        	cancel(idr);
        	
        	break;
        	
        case "list":
        	String venues = json.getString("venue");
        	list(venues);
        	break;
        	
        // TODO Implement other commands
        }
    }

    private int addRoom(String venuea, String rooma, String sizea) {
        room r = new room(venuea, rooma, sizea);
        this.roomList.add(r);
        for(int i = 0; i < venueList.size();i++) {
        	if(venuea.equals(venueList.get(i).venuea)) {
        		//venueList.get(i).addRoom(venuea, rooma, sizea);
        		return 0;
        	}
        }
    	venue a = new venue(venuea, rooma, sizea);
    	this.venueList.add(a);
    	return 0;
    }
    
    public JSONObject request(String id, LocalDate start, LocalDate end,
            int small, int medium, int large) {
        JSONObject result = new JSONObject();
        //for all booking details
        
        JSONArray rooms = new JSONArray();
        JSONArray buffer = new JSONArray();
        //String[] RoomName = new String[small + medium + large];
        if(small == 0 && medium == 0 && large == 0) {
        	result.put("status", "rejected");
        	return result;
        }
        for(venue venue: venueList) {
        	//if(search(large, "large", start, end, venue.venuea)) {
        	//	System.out.println("1");
        	//}
        	if(search(small, "small", start, end, venue.venuea) && search(medium, "medium", start, end, venue.venuea) && search(large, "large", start, end, venue.venuea)) {
        		if(small != 0) {
        			rooms = BookedRooms(small, "small", start, end, venue.venuea);
        		}
        		if(medium != 0) {
        			buffer = BookedRooms(medium, "medium", start, end, venue.venuea);
        			for(int i = 0; i < buffer.length();i++) {
        				rooms.put(buffer.getString(i));
        			}
        		}
        		if(large != 0) {
        			buffer = BookedRooms(large, "large", start, end, venue.venuea);
        			for(int i = 0; i < buffer.length();i++) {
        				rooms.put(buffer.getString(i));
        			}
        		}
        		result.put("status", "success");
        		result.put("venue", venue.venuea);
        		result.put("rooms", rooms);
        		booking booking = new booking(result, id, start, end, rooms);
        		bookingList.add(booking);
        		//System.out.println(booking.RoomName.getString(2));
        		return result;
        	}
        	
        }
        result.put("status", "rejected");
        return result;
        // TODO Process the request commmand
        // FIXME Shouldn't always produce the same answer
        // if no suitable room
        //result.put("status", "rejected");
        // if success
        //JSONArray rooms = new JSONArray();
        /*rooms.put("Penguin");
        rooms.put("Hippo");

        result.put("rooms", rooms);
        
        booking.put(result);
        booking.put(id);
        booking.put(start);
        booking.put(end);*/
    }
    
    
    private int change(String id, LocalDate start, LocalDate end,
            int small, int medium, int large) {
    	JSONObject result = new JSONObject();  																				
    	for (booking booking: bookingList) {								
    		if (booking.id.equals(id)) {							
    			booking duplicate = new booking(booking.result, booking.id, booking.start, booking.end, booking.RoomName);
    			bookingList.remove(booking);								
    			result = request(id, start, end, small, medium, large); 
        		if (result.getString("status").equals("rejected")) {	
        			bookingList.add(duplicate);
        		}
    			System.out.println(result.toString());
    			return 1;
    		}
    	}												
    	result.put("status", "rejected");
    	System.out.println(result.toString());
    	return 0;
    }
    
    private int cancel(String id) {
    	JSONObject result = new JSONObject();
    	for(int i = 0; i < bookingList.size();i++) {
    		if(bookingList.get(i).id.equals(id)) {
    			bookingList.remove(i);
    			result.put("status","success");
    			System.out.println(result.toString());
    			return 0;
    		}
    	}
    	result.put("status","rejected");
    	System.out.println(result);
    	return 0;
    }
     	
    private void list(String venue) {
    	bookingList = sort(bookingList);							
    	JSONArray results = new JSONArray();							
    	for (venue Venue: venueList) {
    		if (Venue.venuea.equals(venue)) {
    			for (int i = 0; i < roomList.size();i++) {
    				if(roomList.get(i).venue.equals(Venue.venuea)) {
	    				JSONArray reservation = new JSONArray();			
	    				JSONObject result = new JSONObject();				
	    				result.put("room", roomList.get(i).roomName);
	    				for (booking booking: bookingList) {						
	    					for (int j = 0;j < booking.RoomName.length();j++) {
		    					if (booking.RoomName.getString(j).equals(roomList.get(i).roomName)) {			
		    						JSONObject book = new JSONObject();
		    						book.put("id", booking.id);
		    						book.put("start", booking.start);
		    						book.put("end", booking.end);
		    						reservation.put(book);
		    					}
	    					}
	    				}
	    				result.put("reservations", reservation);
	    				results.put(result);
    				}
    			}
    		}
    	}
    	System.out.println(results.toString(1));
    }

    public boolean search(int type, String size, LocalDate start, LocalDate end, String venue) {
    	int error = 0;
    	int s = 0;
    	if(type != 0) {
        	for(int i = 0; i < roomList.size();i++) {	//the name of all rooms
        		if(roomList.get(i).size.equals(size) && roomList.get(i).venue.equals(venue)) {	//if it is small room
        			for(int j = 0; j < bookingList.size() && error == 0;j++) {	//which booking
        				for(int k = 0;k < bookingList.get(j).RoomName.length() && error == 0;k++) {
        					if(bookingList.get(j).RoomName.getString(k).equals(roomList.get(i).roomName) ) {
        						LocalDate beginDateTime = bookingList.get(j).start;
        						LocalDate endDateTime = bookingList.get(j).end;
        						if(beginDateTime.isBefore(end) && beginDateTime.isAfter(start)) {
        							error = 1;
        						}
        						if(endDateTime.isBefore(end) && endDateTime.isAfter(start)) {
        							error = 1;
        						}
        						if(start.isAfter(beginDateTime) && start.isBefore(endDateTime)) {
        							error = 1;
        						}
        						if(start.isEqual(beginDateTime) || start.isEqual(endDateTime) || end.isEqual(beginDateTime) || end.isEqual(endDateTime)) {
        							error = 1;
        						}
        					}
        				}
        			}
        			//System.out.println(error);
        			//we can book now
        			if(error == 0) {
        		        s++;
        		        if(s == type) {
        		        	i = roomList.size();
        		        	return true;
            			}
        			}else {
        				error = 0;
        			}
        			
        		}
        	}
        	if(s != type) {
        		return false;
        	}
        }else {
        	return true;
        }
    	return false;
    }
    
    public JSONArray BookedRooms(int number, String type, LocalDate start, LocalDate end, String venueName) {
    	JSONArray rooms = new JSONArray();
    	int error = 0;
    	int s = 0;
    	
    	for(int i = 0; i < roomList.size();i++) {	//the name of all rooms
    		if(roomList.get(i).size.equals(type) && roomList.get(i).venue.equals(venueName)) {	
    			for(int j = 0; j < bookingList.size() && error == 0;j++) {	//which booking
    				for(int k = 0;k < bookingList.get(j).RoomName.length() && error == 0;k++) {
    					if(bookingList.get(j).RoomName.getString(k).equals(roomList.get(i).roomName) && roomList.get(i).venue.equals(venueName)) {
    						LocalDate beginDateTime = bookingList.get(j).start;
    						LocalDate endDateTime = bookingList.get(j).end;
    						if(beginDateTime.isBefore(end) && beginDateTime.isAfter(start)) {
    							error = 1;
    						}
    						if(endDateTime.isBefore(end) && endDateTime.isAfter(start)) {
    							error = 1;
    						}
    						if(start.isAfter(beginDateTime) && start.isBefore(endDateTime)) {
    							error = 1;
    						}
    						if(start.isEqual(beginDateTime) || start.isEqual(endDateTime) || end.isEqual(beginDateTime) || end.isEqual(endDateTime)) {
    							error = 1;
    						}
    					}
    				}
    			}
    			//we can book now
    			if(error == 0) {
    		        s++;
    		        rooms.put(roomList.get(i).roomName);
    		        if(s == number) {
    		        	i = roomList.size();
    		        	return rooms;
        			}
    			}else {
    				error = 0;
    			}
    			
    		}
    	}
        
    	return rooms;
    }
    
    public ArrayList<booking> sort(ArrayList<booking> bookingList) {	
    	ArrayList<booking> sorted = new ArrayList<booking>();
    	while (bookingList.size() > 0) {
    		booking begin = bookingList.get(0);
	    	for (int i = 1; i < bookingList.size(); i++) {
	    		if (bookingList.get(i).start.isBefore(begin.start)) {
	    			begin = bookingList.get(i);
	    		}
	    	}
	    	sorted.add(begin);
	    	bookingList.remove(begin);
    	}
    	
    	return sorted;
    }
    
    public static void main(String[] args) {
        VenueHireSystem system = new VenueHireSystem();

        Scanner sc = new Scanner(System.in);

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            if (!line.trim().equals("")) {
                JSONObject command = new JSONObject(line);
                system.processCommand(command);
            }
        }
        sc.close();
    }

}
