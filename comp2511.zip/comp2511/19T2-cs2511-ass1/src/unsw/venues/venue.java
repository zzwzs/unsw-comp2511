package unsw.venues;

import java.util.ArrayList;

import org.json.JSONObject;

public class venue extends VenueHireSystem {
	public JSONObject venues = new JSONObject();
	public String venuea;
	public ArrayList<room> roomList;
	//public String sizea;
	
	public venue(String venuea, String rooma, String sizea) {
		//super(venueList);
		this.venuea = venuea;
		
		//this.roomList.add(r);
		//this.sizea = sizea;
	}
	
	public void addRoom(String venuea, String rooma, String sizea) {
		room r = new room(venuea, rooma, sizea);
		roomList.add(r);
	}
	/*public int addVenue() {
		venues = venueList;
		for(String str: venues.keySet()){
    	    if(venues.getString(str) == venuea){
    	        return 0;
    	    }
    	}
    	venues.put("venue" + venues.length(), venuea);
    	return 0;
	}*/
}
