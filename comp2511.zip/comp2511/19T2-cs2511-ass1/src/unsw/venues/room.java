package unsw.venues;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;

public class room extends VenueHireSystem{
	public String venue;
	public String roomName;
	public String size;

	
	public room(String venuea, String rooma, String sizea) {
		//super(roomList);
		venue = venuea;
		roomName = rooma;
		size = sizea;
	}
	
}
