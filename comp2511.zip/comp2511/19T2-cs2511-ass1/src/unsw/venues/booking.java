package unsw.venues;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;

public class booking extends VenueHireSystem{
	public JSONObject result;
	public JSONArray RoomName;
	//public JSONArray bookingL;
	public LocalDate start;
	public LocalDate end;
	public String id;
	
	public booking(JSONObject result, String id, LocalDate start, LocalDate end,  JSONArray array) {
		//super(bookingList);
		this.result = result;
		this.id = id;
		this.start = start;
		this.end = end;
		RoomName = array;
	}
	
	public void addBooking() {
		//bookingL = bookingList;
		//bookingL.put(booking()
	}
}
