package unsw.movies;

public class NewRelease implements Price {

    @Override
    public double getCharge(int daysRented) {
        return daysRented * 3;
    }

	@Override
	public Price transferRegular() {
		System.out.println("Transfer to Regular");
		
		return new Regular();
	}

	@Override
	public Price transferClassic() {
		System.out.println("Transfer to Classic");
		
		return new Classic();
	}

	@Override
	public Price transferChildren() {
		System.out.println("Transfer to Chilrens");
		
		return new Childrens();
	}

	@Override
	public Price transferNewRelease() {
		System.out.println("Sorry, you can't transfer to itself");
		
		return this;
	}

}
