package unsw.movies;

public class Regular implements Price {

    @Override
    public double getCharge(int daysRented) {
        double charge = 2;
        if (daysRented > 2)
            charge += (daysRented - 2) * 1.5;
        return charge;
    }

	@Override
	public Price transferRegular() {
		System.out.println("Sorry, you can't transfer to itself");
		
		return this;
	}

	@Override
	public Price transferClassic() {
		System.out.println("Transfer to Classic");
		
		return new Classic();
	}

	@Override
	public Price transferNewRelease() {
		System.out.println("Sorry, you can't transfer to New Release");
		
		return this;
	}
	
	@Override
	public Price transferChildren() {
		System.out.println("Transfer to Childrens");
		
		return new Childrens();
	}

}
