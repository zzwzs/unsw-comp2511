package unsw.movies;

public class Childrens implements Price {

    @Override
    public double getCharge(int daysRented) {
        double charge = 1.5;
        if (daysRented > 3)
            charge += (daysRented - 3) * 1.5;
        return charge;
    }

	@Override
	public Price transferRegular() {
		System.out.println("Sorry, you can't transfer to regular");
		
		return this;
	}

	@Override
	public Price transferClassic() {
		System.out.println("Transfer to classic");
		
		return new Classic();
	}

	@Override
	public Price transferChildren() {
		System.out.println("Sorry, you can't transfer to itself");
		
		return this;
	}

	@Override
	public Price transferNewRelease() {
		System.out.println("Sorry, you can't transfer to new release");
		
		return this;
	}
}