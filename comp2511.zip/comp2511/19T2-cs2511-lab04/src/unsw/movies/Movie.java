package unsw.movies;

public class Movie {
    private String title;
    private Price states;

    public Movie(String title, Price states) {
        this.title = title;
        this.states = states;
    }

    public void setState(Price state) {
        this.states = state;
    }

    public String getTitle() {
        return title;
    }

    public double getCharge(int daysRented) {
        return states.getCharge(daysRented);
    }
    
    /**
     * transfer to other states
     */
    
	public void transferToRegular() {
		this.states = states.transferRegular();
	}

	public void transferToClassic() {
		this.states = states.transferClassic();
	}

	public void transferToChildren() {
		this.states = states.transferChildren();
	}

	public void transferToNewRelease() {
		this.states = states.transferNewRelease();
	}

}