package unsw.movies;

public interface Price {
    public double getCharge(int daysRented);
    public Price transferRegular();
    public Price transferClassic();
    public Price transferChildren();
    public Price transferNewRelease();
}
