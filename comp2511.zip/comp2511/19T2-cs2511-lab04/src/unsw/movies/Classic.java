package unsw.movies;

public class Classic implements Price {
	
	@Override
    public double getCharge(int daysRented) {
		double charge0 = 2;
        double charge5 = 1;
        double charge = 0;
        if (daysRented <= 5) {
            charge += charge0;
        }else {
        	charge = charge + 10;
        	charge += (daysRented - 5) * charge5;
        }
        return charge;
    }

	@Override
	public Price transferClassic() {
		System.out.println("Sorry, you can't transfer to itself");
		
		return this;
	}
	
	@Override
	public Price transferRegular() {
		System.out.println("Sorry, you can't transfer to regular");
		
		return this;
	}


	@Override
	public Price transferNewRelease() {
		System.out.println("Sorry, you can't transfer to new release");
		
		return this;
	}
	
	@Override
	public Price transferChildren() {
		System.out.println("Sorry, you can't transfer to childrens");
		
		return this;
	}

}
