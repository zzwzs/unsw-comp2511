package unsw.enrolment;

import java.util.ArrayList;

// composite class
public class Average implements Mark{
	private ArrayList<PureMark> marks;
	public Average() {
	}

	public int CalculateMark() {
		//return (mark1 + mark2)/2;
		
		int i = 0;
		for (PureMark m : marks) {
			// average calculation...
			i += m.CalculateMark();
		}
		i = i/marks.size();
		return i;
	}

	public void AddMarks(PureMark p) {
		marks.add(p);
	}
	
	public void remove() {
		marks = null;
	}
}
