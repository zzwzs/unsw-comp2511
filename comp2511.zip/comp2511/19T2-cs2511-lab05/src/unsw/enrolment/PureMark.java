package unsw.enrolment;

import java.util.Observable;

public class PureMark extends Observable implements Mark {
	private int mark;
	private String name;
	
	public PureMark(int mark, String name) {
		this.mark = mark;
		this.name = name;
	}
	@Override
	public int CalculateMark() {
		// TODO Auto-generated method stub
		return mark;
	}
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	public int getMark() {
		// TODO Auto-generated method stub
		return mark;
	}

}
