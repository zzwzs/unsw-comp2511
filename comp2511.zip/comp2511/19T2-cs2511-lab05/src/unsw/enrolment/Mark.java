package unsw.enrolment;

// Component interface
public interface Mark {	
	public int CalculateMark();
}
