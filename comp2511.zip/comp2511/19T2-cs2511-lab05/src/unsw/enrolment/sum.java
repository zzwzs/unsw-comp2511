package unsw.enrolment;

import java.util.ArrayList;

// composite class
public class sum implements Mark{
	private ArrayList<PureMark> marks;
	
	public sum() {
		
	}
	@Override
	public int CalculateMark() {
		int s = 0;
		for(PureMark m : marks) {
			s += m.CalculateMark();
		}
		
		return s;
	}
	
	public void add(PureMark a) {
		marks.add(a);
	}
	
	public void remove() {
		marks = null;
	}
}
