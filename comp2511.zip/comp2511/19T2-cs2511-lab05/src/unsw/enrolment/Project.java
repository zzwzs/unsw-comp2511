package unsw.enrolment;

public class Project {
	private String ProName;
	private int mark;
	
	public Project(String ProName, int mark){
		this.ProName = ProName;
		this.mark = mark;
	}
	
	public int getMark() {
		return mark;
	}
}
