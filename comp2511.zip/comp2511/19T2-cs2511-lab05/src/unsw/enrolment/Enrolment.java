package unsw.enrolment;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class Enrolment implements Observer{

    private CourseOffering offering;
    private Grade grade;
    private Student student;
    private List<Session> sessions;
    private int marks;
    private List<Project> project;
    private PureMark updatedMark;


    public Enrolment(CourseOffering offering, Student student, Session... sessions) {
        this.offering = offering;
        this.student = student;
        this.grade = null; // Student has not completed course yet.
        this.marks = 0;
        student.addEnrolment(this);
        offering.addEnrolment(this);
        this.sessions = new ArrayList<>();
        this.project = new ArrayList<>();
        for (Session session : sessions) {
            this.sessions.add(session);
        }
    }
    
    public void addObserver(Observable o) {
    	o.addObserver(this);
    }
    
    public void removeObserver(Observable o) {
    	o.deleteObserver(this);
    }

    
    public Course getCourse() {
        return offering.getCourse();
    }

    public String getTerm() {
        return offering.getTerm();
    }

    public Project getProject(int index) {
    	return this.project.get(index);
    }
    public boolean hasPassed() {
        return grade != null && grade.isPassing();
    }

//    Whole course marks can no longer be assigned this way.
//    public void assignMark(int mark) {
//        grade = new Grade(mark);
//    }
    public void setMark(int mark){
    	this.marks = mark;
    }
    
    /*public double averageMark(int mark1, int mark2) {
    	return (mark1 + mark2)/2;
    }*/
    
    public void newPro(int mark, String ProName) {
    	Project Pro = new Project(ProName, mark);
    	project.add(Pro);
    }
    
    public void assignMark() {
    	grade = new Grade(marks);
    }
    
    public int getEndMark() {
    	return marks;
    }

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if (o instanceof PureMark) {
    		PureMark m = (PureMark) o;
    		this.updatedMark = m;
    	}
    	display();

	}
	
	public void display() {
		String course = offering.getCourse().getCourseCode();
    	String term = this.getTerm();
    	String zid = this.getZid();
    	String fileName = course + "-" + term + "-" + zid;
    	
    	try {
    		FileWriter f = new FileWriter(fileName, true);
    		f.write("markschanged --> " + updatedMark.getName() + ": " + updatedMark.getMark() + "\n");
    		f.close();
    	}
    	catch(IOException ioe) {
    		System.err.println(ioe.getMessage());
    	}

	}

	private String getZid() {
		// TODO Auto-generated method stub
		return student.getZID();
	}
}
