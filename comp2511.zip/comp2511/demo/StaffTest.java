package example;

import java.time.LocalDate;

public class StaffTest {

  public static void printStaffDetails(StaffMember s){
    System.out.println(s.toString());
  }
  
  public static void main(String[] args) {
    System.out.println("WEEK02 LAB: Staff & Lecturer Demo");

    StaffMember s = new StaffMember("rzw", 1, LocalDate.of(2016, 11, 30), LocalDate.now());
    //System.out.println(s.toString());
    StaffMember s1 = new StaffMember("rzw", 1, LocalDate.of(2016, 11, 30), LocalDate.now());
    StaffMember s2 = new StaffMember("rzw", 1, LocalDate.of(2016, 11, 30), LocalDate.now());
    Lecturer l = new Lecturer("rzw", 1, LocalDate.of(2016, 11, 30), LocalDate.now(), "UNSW", "A");
    //System.out.println(l.toString());
    
    printStaffDetails(s);
    printStaffDetails(l);
    
    if (s.equals(s)){
    	System.out.println("s == s is True");
    }
    else {
    	System.out.println("s == s is False");
    }
    
    if (s.equals(s1)) {
    	System.out.println("s == s1 is True");
    }
    else {
    	System.out.println("s == s1 is False");
    }
    
    if (s.equals(l)) {
    	System.out.println("s == l is True");
    }
    else {
    	System.out.println("s == l is False");
    }
    
    if (s.equals(s1) && s1.equals(s2)) {
    	if (s.equals(s2)) {
    		System.out.println("s == s1 == s2 is True");
    	}
    	else {
    		System.out.println("s == s1 == s2 is False");
    	}
    }
    
    if (s.equals(null)) {
    	System.out.println("s == null is True");
    }
    else {
    	System.out.println("s == null is False");
    }
    /**
    *test equals
    */
    
  }
}
