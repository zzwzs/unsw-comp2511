package example;

import java.time.LocalDate;

public class Lecturer extends StaffMember{
    public String school;
    public String academic_status;
    
	//public Lecturer(String name, float salary, LocalDate hiredate, LocalDate enddate) {
		//super(name, salary, hiredate, enddate);
		//this.school = school;
		//this.academic_status = academic_status;
		// TODO Auto-generated constructor stub
	//}
	
	public Lecturer(String name, float salary, LocalDate hiredate, LocalDate enddate, String school, String academic_status) {
		super(name, salary, hiredate, enddate);
		this.school = school;
		this.academic_status = academic_status;
	}
	
    /**set school and get school
	 * 
	 * @return
	 */
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	
	 /**set academic_status and get academic_status
	 * 
	 * @return
	 */
	public String getAcademic_status() {
		return academic_status;
	}
	public void setAcademic_status(String academic_status) {
		this.academic_status = academic_status;
	}
    
    /**
	 * hashCode and equals
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((academic_status == null) ? 0 : academic_status.hashCode());
		result = prime * result + ((school == null) ? 0 : school.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lecturer other = (Lecturer) obj;
		if (academic_status == null) {
			if (other.academic_status != null)
				return false;
		} else if (!academic_status.equals(other.academic_status))
			return false;
		if (school == null) {
			if (other.school != null)
				return false;
		} else if (!school.equals(other.school))
			return false;
		return true;
	}
	
	/**
	*toString
	*/
	@Override
	public String toString() {
		return "StaffMember [name is " + name + ", salary=" + salary + ", hiredate=" + hiredate + ", enddate=" + enddate + ", school is " + school + ", academic_status=" + academic_status + "]";
	}

	

}
