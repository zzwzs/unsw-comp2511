package example;

import java.time.LocalDate;
/**import java.time.LocalDate;
 * A staff member
 * @author Robert Clifton-Everest
 *
 */
public class StaffMember {
	public String name;
	public float salary;
	public LocalDate hiredate;
	public LocalDate enddate;

	/**set name and get name
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/**set salary and get salary
	 * 
	 * @return
	 */
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	/**set and get hiredate
	 * 
	 * @return
	 */
	public LocalDate getHiredate() {
		return hiredate;
	}
	public void setHiredate(LocalDate format) {
		this.hiredate = format;
	}
	
	/**set and get enddate
	 * 
	 * @return
	 */
	public LocalDate getEnddate() {
		return enddate;
	}
	public void setEnddate(LocalDate format) {
		this.enddate = format;
	}
	
	/**
	 * hashCode and equals
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hiredate == null) ? 0 : hiredate.hashCode());
		result = prime * result + ((enddate == null) ? 0 : enddate.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + Float.floatToIntBits(salary);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StaffMember other = (StaffMember) obj;
		if (hiredate == null) {
			if (other.hiredate != null)
				return false;
		} else if (!hiredate.equals(other.hiredate))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Float.floatToIntBits(salary) != Float.floatToIntBits(other.salary))
			return false;
		return true;
	}
	
	/**
	*toString
	*/
	@Override
	public String toString() {
		return "StaffMember [name=" + name + ", salary=" + salary + ", hiredate=" + hiredate + ", enddate=" + enddate + "]";
	}
	public StaffMember(String name, float salary, LocalDate hiredate, LocalDate enddate) {
		this.name = name;
		this.salary = salary;
		this.hiredate = hiredate;
		this.enddate = enddate;
	}

	
	
}
