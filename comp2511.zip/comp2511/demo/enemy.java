package unsw.dungeon;

import java.util.Timer; 
import java.util.TimerTask;

public class Enemy extends Entity implements Observer{
	public int player_x;
	public int player_y;
	public Enemy(int x, int y) {
		super(x, y);
	}

	public void enemyMove(int x, int y, Dungeon dungeon) { // always move to the left
		player_x = x;
		player_y = y;
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				if(x!= player_x || y!= player_y) {
					cancel();
				}
				move(x, y, dungeon);
			}
		}, 1000, 1000);
	}

		

	@Override
	public void update(Observable o) {
		if (o instanceof Player) {
			Player player = (Player) o;
			System.out.println("Player now at: " + player.getX() + " " + player.getY());
			enemyMove(player.getX(), player.getY(), player.getDungeon());
		}
	}
	
	public boolean checkBarrier(int x, int y, Dungeon dungeon) {
    	for (Entity entity : dungeon.getEntities()){
    		if (entity.getX() == x && entity.getY() == y) {
    			if (entity instanceof Wall || entity instanceof Boulder || entity instanceof Door || entity instanceof Enemy) {
    				return true;
    			}
    		}
    	}
    	return false;
    }
	
	public boolean checkPlayer(int x, int y, int Px, int Py) {
		if (x == Px && y == Py) {
			return true;
		}else {
			return false;
		}
	}
	
	public void move(int Px, int Py, Dungeon dungeon) {
		if (getX() - Px > 0) {
			int x = getX() - 1;
			int y = getY();
			if (checkPlayer(x, y, Px, Py) == true) {
				dungeon.getPlayer().notAlive();
			}
			if (dungeon.getPlayer().getStatus()) {
				x = getX() + 1;
				y = getY();
				if (checkBarrier(x, y, dungeon) == false) {
					x().set(x);
					return;
				}
			}else {
				if (getX() > 0) {
					x = getX() - 1;
					y = getY();
					if (checkBarrier(x, y, dungeon) == false) {
						x().set(x);
						return;
					}
				}
			}
		}
		if (getX() - Px < 0) {
			int x = getX() + 1;
			int y = getY();
			if (checkPlayer(x, y, Px, Py) == true) {
				dungeon.getPlayer().notAlive();
			}
			if (dungeon.getPlayer().getStatus()) {
				if (getX() > 0) {
					x = getX() - 1;
					y = getY();
					if (checkBarrier(x, y, dungeon) == false) {
						x().set(x);
						return;
					}
				}
			}else {
				x = getX() + 1;
				y = getY();
				if (checkBarrier(x, y, dungeon) == false) {
					x().set(x);
					return;
				}
			}
		}
		if (getY() - Py > 0) {
			int x = getX();
			int y = getY() - 1;
			if (checkPlayer(x, y, Px, Py) == true) {
				dungeon.getPlayer().notAlive();
			}
			if (dungeon.getPlayer().getStatus()) {
				x = getX();
				y = getY() + 1;
				if (checkBarrier(x, y, dungeon) == false) {
					y().set(y);
					return;
				}
			}else {
				if (getY() > 0) {
					x = getX();
					y = getY() - 1;
					if (checkBarrier(x, y, dungeon) == false) {
						y().set(y);
						return;
					}
				}
			}
		}
		if (getY() - Py < 0) {
			int x = getX();
			int y = getY() + 1;
			if (checkPlayer(x, y, Px, Py) == true) {
				dungeon.getPlayer().notAlive();
			}
			if (dungeon.getPlayer().getStatus()) {
				if (getY() > 0) {
					x = getX();
					y = getY() - 1;
					if (checkBarrier(x, y, dungeon) == false) {
						y().set(y);
						return;
					}
				}
			}else {
				x = getX();
				y = getY() + 1;
				if (checkBarrier(x, y, dungeon) == false) {
					y().set(y);
					return;
				}
			}
		}
	}
}


