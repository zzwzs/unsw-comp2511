package unsw.dungeon;

import java.util.ArrayList;
import java.util.Timer; 
import java.util.TimerTask;
/**
 * The player entity
 * @author Robert Clifton-Everest
 *
 */
public class Player extends Entity implements Observable{

    private Dungeon dungeon; 
    private Sword player_sword;								// if player holds a sword, then player_sword = the sword it holds, otherwise player_sword = null
    private ArrayList<Bomb> bombs;							// an ArrayList contains all collected bombs
    private Key key;										// if player holds a key, then key = the key it holds, otherwise key = null
    private ArrayList<Treasure> treasure;					// an ArrayList contains all collected treasure
    private boolean Invicibility;							// a status that checks whether the player has collected the invincible potion (true) or not (false)
    private boolean alive;									// a status that checks whether the player is still alive (return true) or not (return false)
    private ArrayList<Observer> observers;					// an ArrayList contains all observers
    

    /**
     * Create a player positioned in square (x,y)
     * @param x
     * @param y
     */
    public Player(Dungeon dungeon, int x, int y) {
        super(x, y);
        this.dungeon = dungeon;
    	player_sword = null;
    	key = null;
    	treasure = new ArrayList<Treasure>();
    	bombs = new ArrayList<Bomb>();
    	Invicibility = false;
    	alive = true;
    	observers =  new ArrayList<Observer>();
    	
    }

	/**
	 * the player moves towards up and check some conditions
	 */
	
	public void moveUp() {
		addallObservers();
		if (getY() > 0) {
			int x = this.getX();
			int y = this.getY()-1;
			if(checkWall(x,y) == false && faceDoor(x,y) == true) {
				if(pushBoulder(x, y, x, y-1)) {
					y().set(getY() - 1);
					measurementsChanged();
					System.out.println(getX()+" "+getY());
				}
			}
			this.pickSword(x, y);
			this.pickBombs(x, y);
			this.pickKey(x, y);
			this.pickTreasure(x, y);
			this.pickPotion(x, y);
			this.collideEnemy(x, y);
			this.checkSwitch();
			if (dungeon.getGoal() != null) {
				dungeon.getGoal().checkGoal(dungeon, this);
			}
		}
	}
	
	/**
	 * the player moves towards down and check some conditions
	 */
	
	public void moveDown() {
		addallObservers();
		if (getY() < dungeon.getHeight() - 1) {
			int x = this.getX();
			int y = this.getY()+1;
			if(checkWall(x, y) == false && faceDoor(x,y) == true) {
				if(pushBoulder(x, y, x, y+1)) {
					y().set(getY() + 1);
					measurementsChanged();
					System.out.println(getX()+" "+getY());
				}
			}
			this.pickSword(x, y);
			this.pickBombs(x, y);
			this.pickKey(x, y);
			this.pickTreasure(x, y);
			this.pickPotion(x, y);
			this.collideEnemy(x, y);
			this.checkSwitch();
			if (dungeon.getGoal() != null) {
				dungeon.getGoal().checkGoal(dungeon, this);
			}
		}
	}
	
	/**
	 * the player moves to the left and check some conditions
	 */
	
	public void moveLeft() {
		addallObservers();
		if (getX() > 0) {
			int x = this.getX()-1;
			int y = this.getY();
			if(checkWall(x,y) == false && faceDoor(x,y) == true) {
				if(pushBoulder(x, y, x-1, y)) {
					x().set(getX() - 1);
					measurementsChanged();
					System.out.println(getX()+" "+getY());
				}
			}
			this.pickSword(x, y);
			this.pickBombs(x, y);
			this.pickKey(x, y);
			this.pickTreasure(x, y);
			this.pickPotion(x, y);
			this.collideEnemy(x, y);
			this.checkSwitch();
			if (dungeon.getGoal() != null) {
				dungeon.getGoal().checkGoal(dungeon, this);
			}
		}
	}
	
	/**
	 * the player moves to the right and check some conditions
	 */
	
	public void moveRight() {
		addallObservers();
		if (getX() < dungeon.getWidth() - 1) {
			int x = this.getX()+1;
			int y = this.getY();
			if(checkWall(x,y) == false && faceDoor(x,y) == true) {
				if(pushBoulder(x, y, x+1, y)) {
					x().set(getX() + 1);
					measurementsChanged();
					System.out.println(getX()+" "+getY());
				}
			}
			this.pickSword(x, y);
			this.pickBombs(x, y);
			this.pickKey(x, y);
			this.pickTreasure(x, y);
			this.pickPotion(x, y);
			this.collideEnemy(x, y);
			this.checkSwitch();
			if (dungeon.getGoal() != null) {
				dungeon.getGoal().checkGoal(dungeon, this);
			}
		}
	}
    
    /**
     * check whether there is a wall in (x, y) on the map or not
     * @param x
     * @param y
     * @return if there is a wall in (x, y) return true, otherwise return false
     */
    
    public boolean checkWall(int x, int y) {
    	for(Entity entity : dungeon.getEntities()){
    		if(entity.getX() == x && entity.getY() == y) {
    			if(entity instanceof Wall) {
    				System.out.println("check"+entity.getX()+" "+entity.getY());
    				return true;
    			}
    		}
    	}
    	return false;
    }
    
    /**
     * check whether there is a boulder on the switch
     */
    
    public void checkSwitch() {
    	for (Entity e1: dungeon.getEntities()) {
    		if (e1 instanceof Switch) {
    			Switch s = (Switch) e1;
    			for (Entity e2: dungeon.getEntities()) {
    				if (e2.getY() == e1.getY() && e2.getX() == e1.getX()) {
    					if (e2 instanceof Boulder) {							// if there is a boulder on the switch
    						s.isTriggered();									// transfer the state of the switch to isTriggered
    						break;
    					}else {
    						s.notTriggered();									// otherwise transfer the state of the switch to notTriggered
    					}
    				}
    			}
    		}
    	}
    }
    
    /**
     * check whether the square contains an enemy or not
     * @param x
     * @param y
     * @return if there is an enemy in (x, y) return true, otherwise return false
     */
    
  	public boolean checkEnemy(int x, int y) {
      	for(Entity entity : dungeon.getEntities()){
      		if (entity instanceof Enemy) {
	      		if(entity.getX() == x && entity.getY() == y) {
	      			return true;
	      		}
      		}
      	}
      	return false;
  	}
  	
    /**
     * check whether the door faced is opened or closed
     * @param x
     * @param y
     * @return if the door is opened then return true, otherwise return false
     */
    
    public Boolean faceDoor(int x, int y) {
      	for(Entity entity : dungeon.getEntities()){
      		if(entity.getX() == x && entity.getY() == y && entity instanceof Door) { // if the player moves to the square containing a door
      			Door curr = (Door) entity;
      			if(!curr.getOpen()) {											// if the door is closed
	      			if(this.key != null) {										// check whether the player holds a key or not
	      				System.out.println("face the door");
	      				System.out.println("door id "+curr.getId());
	      				if(this.key.getId() == curr.getId()) {					// if the player holds a key and the key is corresponding to the door
	      					this.key = null;									// open the door and the key will disappear
	      					curr.openDoor();
	      					System.out.println("Door opened");
	      					//Door.changestate();  // door state strategy 
	      					return true;
	      				}else {													// otherwise do nothing
	      					return false;
	      				}
	      			}else {
	      				return false;
	      			}
      			}else {
      				return true;
      			}
      		}
      	}
      	return true;
    }
    
    /**
     * if there is a sword in the square where player moves to, pick it up if no sword in hands
     * @param x
     * @param y
     */
    public void pickSword(int x, int y) {
    	for(Entity entity : dungeon.getEntities()){
    		if(entity.getX() == x && entity.getY() == y && entity instanceof Sword) { // if the player moves to the square containing a sword
				if(this.player_sword == null) {									// if the player hasn't held a sword
					this.player_sword = (Sword)entity;
					player_sword.x().set(1);									// put the sword into the backpack(which is the whole line of x = 1 on the map)
					player_sword.y().set(0);
					dungeon.deleteEntity(entity);								// delete the entity on the map
					System.out.println("pick up sword");
					break;
    			}else {
    				System.out.println("already has a sowrd");
    				break;
    			}
    		}
    	}
    }
    
    /**
     * if there is a key in the square where player moves to, pick it up if no key in hands
     * @param x
     * @param y
     */
    
    public void pickKey(int x, int y) {
    	for(Entity entity : dungeon.getEntities()){
    		if(entity.getX() == x && entity.getY() == y && entity instanceof Key) { // if the player moves to the square containing a key
    			if(this.key == null) {											// if the player hasn't held a key
    				this.key = (Key)entity;
    				key.x().set(2);												// put the key into the backpack
    				key.y().set(0);
    				dungeon.deleteEntity(entity);								// delete the key on the map
    				System.out.println("pick up key");
    				System.out.println("key id "+this.key.getId());
    				break;
    			}else {
    				System.out.println("already has a key");
    				break;
    			}
    		}
    	}
    }
    
    /**
     * if there is a potion in the square where player moves to, pick it up
     * @param x
     * @param y
     */
    
    public void pickPotion(int x, int y) {
    	for(Entity entity : dungeon.getEntities()){
    		if(entity.getX() == x && entity.getY() == y && entity instanceof Potion) { // if the player moves to the square containing a potion
    			Potion potion = (Potion) entity;
    			potion.x().set(3);												// put the potion into the backpack
    			potion.y().set(0);
    			dungeon.deleteEntity(entity);									// delete the potion on the map
    			System.out.println("I am invisible");
    			Invicibility = true;											// the player becomes invincible
    			Timer timer = new Timer();
    			timer.schedule(new TimerTask() {								// after 5 second the effect of the potion will fades
    				@Override
    				public void run() {
    					Invicibility = false;
    					potion.x().set(16);										// the used potion will be located in the "used area"
    					potion.y().set(0);
    					System.out.println("Oh I am not invisible anymore");
    				}
    			}, 5000);
    			break;
    		}
    	}
    }
    
    /**
     * if there is a treasure in the square where player moves to, pick it up
     * @param x
     * @param y
     */
    
    public void pickTreasure(int x, int y) {
    	for(Entity entity : dungeon.getEntities()){
    		if(entity.getX() == x && entity.getY() == y && entity instanceof Treasure) { // if the player moves to the square containing a treasure
    			Treasure treasure = (Treasure) entity;
    			treasure.x().set(4);											// put the treasure into the backpack
    			treasure.y().set(0);
    			this.treasure.add(treasure);									// delete the treasure on the map
    			dungeon.deleteEntity(entity);
    			System.out.println("pick up Treasure");
    			break;
    		}
    	}
    }
    
    /**
     * // if there is a bomb in the square where player moves to, pick it up
     * @param x
     * @param y
     */
    
    public void pickBombs(int x, int y) {
      	for(Entity entity : dungeon.getEntities()){
      		if(entity.getX() == x && entity.getY() == y && entity instanceof Bomb) { // if the player moves to the square containing a bomb
      			Bomb bomb = (Bomb) entity;
      			bomb.x().set(5);												// put the bomb into backpack
      			bomb.y().set(0);
      			this.bombs.add(bomb);											// add the collected bomb to the ArrayList bombs
    			dungeon.deleteEntity(entity);									// delete the bomb on the map
    			System.out.println("pick up Bomb");
    			break;
      		}
      	}
    }
    
    /**
     * if there is an enemy in the square where player moves to, kill it or be killed
     * @param x
     * @param y
     */
    
    public void collideEnemy(int x, int y) {
      	for(Entity entity : dungeon.getEntities()){
      		if(entity.getX() == x && entity.getY() == y && entity instanceof Enemy) { // if the player moves to the square containing an enemy
      			if(this.player_sword != null || this.Invicibility == true) {	// check whether the player is invincible or holds a sword or not
      				dungeon.deleteEntity(entity);								// if it is, then kill the enemy
      				System.out.println("An enemy has been slained!");
      				Enemy enemy = (Enemy)entity;
      				enemy.x().set(0);
      				enemy.y().set(0);
      				if (this.player_sword != null) {							// if the player holds a sword
      					this.player_sword.decreaseHP();    						// hitPoints of the sword -1
	      				if(this.player_sword.getHitPoints() <= 0) {				// if hitPoints decrease to 0
	      					System.out.println("My weapon has been destroyed!");
	      					this.player_sword = null;							// the sword will disappear
	      				}
      				}
      			}else {
      				this.alive = false;            								// if not, the player will be killed
      				System.out.println("LOL, u died!");
      			}
      			break;
      		}
      	}
    }
    
    /**
     * if the boulder faced can be pushed, return true and push the boulder to the next square, otherwise return false and stop moving
     * @param x 		the start location of the boulder
     * @param y			the start location of the boulder
     * @param boulder_x the final location of the boulder
     * @param boulder_y the final location of the boulder
     * @return
     */
    
    public boolean pushBoulder(int x,  int y, int boulder_x, int boulder_y) {   // boulder in (x,y), will push to (boulder_x,boulder_y)
      	for(Entity entity : dungeon.getEntities()){
      		if(entity.getX() == x && entity.getY() == y) {						// if there is a boulder in (x, y)
      			if(entity instanceof Boulder) {
	      			Boulder curr = (Boulder)entity;
	      			if(curr.canPush(boulder_x, boulder_y)) {					// if the boulder can be pushed to (boulder_x,boulder_y) then return true
	      				curr.x().set(boulder_x);								// push the boulder to (boulder_x,boulder_y)
	      				curr.y().set(boulder_y);
	      				return true;
	      			}else {
	      				return false;											// otherwise return false
	      			}
      			}
      		}
      	}
      	return true;
    }
  	
  	/**
  	 * check whether the player arrives at the exit
  	 * @param x
  	 * @param y
  	 */
  	
    public void arriveExit(int x, int y) {
      	for(Entity entity : dungeon.getEntities()){
      		if(entity.getX() == x && entity.getY() == y && entity instanceof Exit) {
  			    System.out.println("achieve exit");
      		}
      	}
    }
    
    /**
     * drop the key on the square that the player stands on
     */
    
    public void dropKey() {
    	if(this.key != null) {													// if the player holds a key
	    	this.key.y().set(this.getY());										// drop the key on the square that the player stands on
	    	this.key.x().set(this.getX());
	    	dungeon.addEntity(key);
	    	this.key = null;													// the player doesn't held this key anymore
    	}
    }
    
    /**
     * throw the bomb to the square that the player stands on
     */
    
    public void throwBomb() {
    	if(this.bombs.size() != 0) {											// if the player has a bomb
	    	Bomb curr = this.bombs.get(bombs.size()-1);
	    	this.bombs.remove(curr);
	    	curr.y().set(this.getY());											// throw the bomb to the square that the player stands on
	    	curr.x().set(this.getX());
	    	dungeon.addEntity(curr);

	    	Timer timer = new Timer();
	        timer.schedule(new TimerTask() {
	            @Override
	            public void run() {
	            	curr.bombExplode();											// after 3 seconds the bomb will explode
	            	curr.x().set(17);											// the exploded bomb will be put to the "used area"
	            	curr.y().set(0);
	            	dungeon.deleteEntity(curr);									// delete the exploded bomb on the map
	            }
	        }, 3000);
    	}
    }
    
    /**
     * add all observers
     */
    
    public void addallObservers() {
    	for(Entity entity: dungeon.getEntities()) {
    		if(entity instanceof Enemy) {
    			registerObserver((Observer)entity);
    		}
    	}
    }
    
    /**
     * register an observer to the player
     */
    
	@Override
	public void registerObserver(Observer observer) {
		if(!observers.contains(observer)) {
			observers.add(observer);
		}
	}
	
	/**
	 * delete an observer to the player
	 */
	
	@Override
	public void removeObserver(Observer observer) {
		observers.remove(observer);
	}
	
	/**
	 * when the player has moved to another square, notify the observers
	 */
	
	@Override
	public void notifyObservers() {
		for(Observer observer: observers) {
			observer.update(this);
		}
	}
	
	public void measurementsChanged() {
		notifyObservers();
	}
	
    /**
     * change the status of the player to dead
     */
    
    public void notAlive() {
    	this.alive = false;
    }
	
    /**
     * getter and setter methods
     */
    
	public Dungeon getDungeon() {
		return this.dungeon;
	}
	
	public boolean getStatus() {
		return Invicibility;
	}
	
	public void setStatus(boolean status) {
		Invicibility = status;
	}
	
	public Key getKey() {
		return key;
	}
    
	public Sword getSword() {
		return player_sword;
	}
	
	public boolean getAlive() {
		return alive;
	}
	
	public ArrayList<Bomb> getBombs(){
		return bombs;
	}
	
	public ArrayList<Treasure> getTreasure(){
		return treasure;
	}

}

