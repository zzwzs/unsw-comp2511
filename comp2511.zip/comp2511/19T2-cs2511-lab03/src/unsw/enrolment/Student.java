package unsw.enrolment;
import java.util.ArrayList;

public class Student {

    private String zid;
    private ArrayList<Enrolment> enrolments;

	public Student(String zid) {
        this.zid = zid;
        setEnrolments(new ArrayList<>());
    }

	public String getZID() {
		return zid;
	}
	
	public void addEnrolments(Enrolment enrolment) {
        getEnrolments().add(enrolment);
    }

	public ArrayList<Enrolment> getEnrolments() {
		return enrolments;
	}

	public void setEnrolments(ArrayList<Enrolment> enrolments) {
		this.enrolments = enrolments;
	}

}
