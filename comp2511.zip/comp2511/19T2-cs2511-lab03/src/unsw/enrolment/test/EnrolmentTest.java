package unsw.enrolment.test;

import java.time.DayOfWeek;
import java.time.LocalTime;

import unsw.enrolment.Course;
import unsw.enrolment.CourseOffering;
import unsw.enrolment.Enrolment;
import unsw.enrolment.Lecture;
import unsw.enrolment.Student;
import unsw.enrolment.Tutorial;

public class EnrolmentTest {

    public static void main(String[] args) {

        // Create courses
        Course comp1511 = new Course("COMP1511", "Programming Fundamentals");
        Course comp1531 = new Course("COMP1531", "Software Engineering Fundamentals");
        comp1531.addPrereq(comp1511);
        Course comp2521 = new Course("COMP2521", "Data Structures and Algorithms");
        comp2521.addPrereq(comp1511);

        CourseOffering comp1511Offering = new CourseOffering(comp1511, "19T1");
        CourseOffering comp1531Offering = new CourseOffering(comp1531, "19T1");
        CourseOffering comp2521Offering = new CourseOffering(comp2521, "19T2");

        // TODO Create some sessions for the courses
        LocalTime L1S = LocalTime.of(10, 15, 00);
        LocalTime L1E = LocalTime.of(12, 00, 00);
        LocalTime T1S = LocalTime.of(10, 15, 00);
        LocalTime T1E = LocalTime.of(12, 00, 00);
        Lecture comp1511L1 = new Lecture("Kingsford", DayOfWeek.MONDAY, L1S, L1E, "ABC");
        Tutorial comp1511T1 = new Tutorial("Kingsford", DayOfWeek.TUESDAY, T1S, T1E, "ABCD");
        // TODO Create a student
        Student S1 = new Student("z5555555");
        // TODO Enrol the student in COMP1511 for T1 (this should succeed)
        Enrolment E1 = Enrol(comp1511, S1, comp1511Offering);
        Enrolment E2 = Enrol(comp1531, S1, comp1531Offering);
        //Enrolment Ecomp1511 = new Enrolment(comp1511Offering, S1);
        if(E1 != null) {
        	E1.SetGrade(50);
        	S1.addEnrolments(E1);
        }
        Enrol(comp2521, S1, comp2521Offering);
        
    }
    
    public static Enrolment Enrol(Course course, Student S1, CourseOffering courseOffering) {
        int error = 1;
	    //lableA:
	    if(!course.getPrereqs().isEmpty()) {															
	    	if(S1.getEnrolments().isEmpty()) {															//if this student has no prereqs
	    		System.out.println("Enrolment fail, check your Prereqs");
	        }else {
	        	for(int i = 0; i < course.getPrereqs().size();i++) {
	        		for(int j = 0; j < S1.getEnrolments().size();j++) {
	        			if(course.getPrereqs().get(i).getTitle() == S1.getEnrolments().get(j).title) {
	        				if(S1.getEnrolments().get(j).GetGrade().getMark() < 50) {					//if this student enrolled the Prereqs course but didn't pass
	        					//error = 0;
	        					System.out.println("Enrolment fail, you have to pass the Prereqs");
	        					//break lableA;
	        				}else {
	        					error = 0;
	        				}
	        			}
	        		}
	        	}																						
	        	if(error == 0) {																		//if this student enrolled the Prereqs course and passed
	        		Enrolment E1 = new Enrolment(courseOffering, S1);
					System.out.println("Enrolment success");
					return E1;
	        	}else {																					
	        		System.out.println("Enrolment fail, check your Prereqs");
	        	}
	        	
	        }
	    }else {     																					//if this course dont need Prereqs course
	        Enrolment E1 = new Enrolment(courseOffering, S1);
	        System.out.println("Enrolment success");
	        return E1;
	    }
    	return null;
    }
        // TODO Enrol the student in COMP1531 for T1 (this should fail as they
        // have not met the prereq)

        // TODO Give the student a passing grade for COMP1511

        // TODO Enrol the student in 2521 (this should succeed as they have met
        // the prereqs)
}
