package unsw.enrolment;

public class Enrolment {

    private CourseOffering offering;
    private Grade grade;
    private Student student;
    public String title;

    public Enrolment(CourseOffering offering, Student student) {
        this.offering = offering;
        this.student = student;
        title = offering.getCourse().getTitle();
    }

    public Course getCourse() {
        return offering.getCourse();
    }

    public String getTerm() {
        return offering.getTerm();
    }
    
    public Grade GetGrade() {
    	return grade;
    }
    public void SetGrade(int mark) {
    	grade = new Grade(mark);
    }

}
