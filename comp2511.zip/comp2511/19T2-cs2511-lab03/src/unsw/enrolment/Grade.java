package unsw.enrolment;

public class Grade {
    private int mark;
    private String grade;
    
    public Grade(int mark) {
    	this.mark = mark;
    	if(mark < 50) {
    		grade = "fail";
    	}else if(mark < 65){
    		grade = "pass";
    	}else if(mark < 75) {
    		grade = "credit";
    	}else if(mark < 85){
    		grade = "distinction";
    	}else {
    		grade = "high distinction";
    	}
    }
    
    public int getMark() {
    	return mark;
    }
    public void setmark(int mark) {
    	this.mark = mark;
    }
    public String getGrade() {
    	return grade;
    }
}

