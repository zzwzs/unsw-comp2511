package car;

import java.util.ArrayList;

public class Body implements CarElement {

	private ArrayList<CarElement> elements = new ArrayList<CarElement>();

	private double cost = 2000;

	public Body() {
		this.elements.add(new BodyPart1());
		this.elements.add(new BodyPart2());
	}

	@Override
	public void accept(CarElementVisitor visitor) {

		for (CarElement element : elements) {
			element.accept(visitor);
		}

		visitor.visit(this);
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
}
