package car;


public interface CarElement {
	
	 void accept(CarElementVisitor visitor);
}


