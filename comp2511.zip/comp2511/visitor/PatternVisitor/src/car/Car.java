package car;

import java.util.ArrayList;

public class Car implements CarElement {
    private ArrayList<CarElement> elements = 
    		new ArrayList<CarElement>();
    
	private double cost = 6000;

    public Car() {        
        this.elements.add( new Wheels() );
        this.elements.add( new Body() );
        this.elements.add( new Engine() );  
    }

    @Override
    public void accept(CarElementVisitor visitor) {
    	
        for (CarElement element : elements) {
            element.accept(visitor);
        }
        
        visitor.visit(this);
    }

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
}