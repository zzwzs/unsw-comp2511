package unsw.fruit;

public interface Fruit {
    public String getName();
}
