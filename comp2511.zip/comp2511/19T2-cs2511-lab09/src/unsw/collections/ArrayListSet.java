/**
 *
 */
package unsw.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

/**
 * An implementation of Set that uses an ArrayList to store the elements.
 *
 * @invariant All e in elements occur only once
 *
 * @author Robert Clifton-Everest
 *
 */
public class ArrayListSet<E> implements Set<E> {

    private ArrayList<E> elements;

    public ArrayListSet() {
        elements = new ArrayList<>();
    }

    @Override
    public void add(E e) {
        if (!elements.contains(e))
            elements.add(e);
    }

    @Override
    public void remove(E e) {
        elements.remove(e);
    }

    @Override
    public boolean contains(Object e) {
        return elements.contains(e);
    }

    @Override
    public int size() {
        return elements.size();
    }

    @Override
    public boolean subsetOf(Set<?> other) {
        for (E element : this.elements) {
        	if(!other.contains(element)) {
        		return false;
        	}
        }
        	
        return true;
    }

    @Override
    public Iterator<E> iterator() {
        // TODO Implement me
    	
        return elements.iterator();
    }

    @Override
    public Set<E> union(Set<? extends E> other) {
    	Set<E> s = this;
    	for(E element : other) {
    		if(!this.contains(element)) {
    			s.add(element);
    		}
    	}

        return s;
    }

    @Override
    public Set<E> intersection(Set<? extends E> other) {
    	Set<E> s = this;
    	for(E element : this.elements) {
    		if(!other.contains(element)) {
    			s.remove(element);
    		}
    	}

        return s;
    }

//	@Override
//	public int hashCode() {
//		return Objects.hash(elements);
//	}

	public boolean equals(Set<?> other) {
		if(this.subsetOf(other) && other.subsetOf(this)) {
			return true;
		}
		return false;
	}

    /**
     * For this method, it should be possible to compare all other possible sets
     * for equality with this set. For example, if an ArrayListSet<Fruit> and a
     * LinkedListSet<Fruit> both contain the same elements they are equal.
     * Similarly, if a Set<Apple> contains the same elements as a Set<Fruit>
     * they are also equal.
     */
    
    

}
