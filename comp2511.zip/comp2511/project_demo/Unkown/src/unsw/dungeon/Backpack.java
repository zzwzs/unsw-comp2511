package unsw.dungeon;

public class Backpack extends Entity{
	public Backpack(int x, int y) {
        super(x, y);
    }
}
