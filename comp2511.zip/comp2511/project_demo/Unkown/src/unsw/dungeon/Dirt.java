package unsw.dungeon;

public class Dirt extends Entity{
	public Dirt(int x, int y) {
        super(x, y);
    }
}
