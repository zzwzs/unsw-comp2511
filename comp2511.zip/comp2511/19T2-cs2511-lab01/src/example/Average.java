package example;

/**
 * Average example
 * @author Aarthi
 */
public class Average {

        /**
         * Returns the average of an array of numbers
         * @param the array of integer numbers
         * @return the average of the numbers
         */
        public float average(int[] nums) {
            /**
             * for(int i = nums.length; i > 0; i-- )
             */
        	float sum = 0;
        	for(int x : nums) {
        		sum = sum + x;
        	}
        	float result = 0;
        	if(nums.length == 0) {
        		return 0;
        	}
        	result = sum / nums.length;
        	
        	/**
        	 * System.out.println(result);
        	 */
            // Add your code
            return result;
        }

        public static void main(String[] args) {
        	int size = 10;
        	int[] array = new int[size];
        	int[] array2 = {};
        	array[0] = 4;
        	array[1] = 3;
        	array[2] = 3;
        	array[3] = 3;
        	array[4] = 5;
        	array[5] = 5;
        	array[6] = 6;
        	array[7] = 1;
        	array[8] = 2;
        	array[9] = 6;
        	/**
        	 * int array[] = {4,3,3,3,5,5,6,1,2,6}
        	 */
        	float result = new Average().average(array);
        	System.out.println(result);
        	result = new Average().average(array2);
        	System.out.println(result);
            // Add your code
        }
}
