/**
package example;


public class Splitter_single_line {

    public static void main(String[] args) throws Exception {
    	byte[] barray = new byte[100];
        System.out.println("Inputs:");
        System.in.read(barray);
        for (int i = 0; barray[i] != 0; i++) {
        	if ((char) barray[i] == ' ') {
        		System.out.println();
        	} else {
        		System.out.print((char) barray[i]);
        	}
        }
    }
}
*/
package example;
import java.util.Scanner;

public class Splitter_single_line {

    public static void main(String[] args) throws Exception {

    	String b;
    	System.out.println("Input:");
    	Scanner inputs = new Scanner(System.in);
    	
    	b = inputs.nextLine();
    	String[] split = b.split(" ");
    	for(int i = 0; i < split.length; i++) {
    		System.out.println(split[i]);
    	}
    		
    	inputs.close();
    }
}
