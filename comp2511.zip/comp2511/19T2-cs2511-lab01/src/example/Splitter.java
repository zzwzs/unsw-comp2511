package example;
import java.util.Scanner;

public class Splitter {

    public static void main(String[] args) throws Exception {
    	/**
    	 * int b;
    	 * int i = 0;
        *char inputs[];
        *inputs = new char[100];
        *System.out.println("Input:");
        *while ((b = System.in.read()) != -1) {
        *    inputs[i] = (char)b;
        *    i++;
        *}
        *System.out.println(inputs);
    	*/
    	String b;
    	System.out.println("Input:");
    	Scanner inputs = new Scanner(System.in);
    	while(inputs.hasNext()) {
    		b = inputs.next();
    		System.out.println(b);
    	}
    	inputs.close();
    }
}
