/**
 *
 */
package unsw.automata;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

/**
 * Conway's Game of Life on a 10x10 grid.
 *
 * @author Robert Clifton-Everest
 *
 */
public class GameOfLife {
	private BooleanProperty World[][] = new BooleanProperty[10][10];
    public GameOfLife() {
        // TODO At the start all cells are dead
    	for(int i = 0; i < 10; i++) {
    		for(int j = 0; j < 10; j++) {
    			World[i][j] = new SimpleBooleanProperty(false);
    		}
    	}
    }

    public void ensureAlive(int x, int y) {
        // TODO Set the cell at (x,y) as alive
    	World[x][y].set(true);
    }

    public void ensureDead(int x, int y) {
        // TODO Set the cell at (x,y) as dead
    	World[x][y].set(false);
    }

    public boolean isAlive(int x, int y) {
        // TODO Return true if the cell is alive
		if(World[x][y].get()) {
			return true;
		}else {
			return false;
		}
    }

    public void tick() {
        // TODO Transition the game to the next generation.
    	boolean Trans[][] = new boolean[10][10];
    	for(int i = 0; i < 10; i++) {
    		for(int j = 0; j < 10; j++) {
    			Trans[i][j] = World[i][j].get();
    		}
    	}
    	int p = 0;
    	for(int i = 0; i < 10; i++) {
    		for(int j = 0; j < 10; j++) {
    			if(isAlive(i,j)) {
    				p = neighbours(i,j);
    				//System.out.print(p);
    				if(p - 1 < 2 || p - 1 > 3) {
    					Trans[i][j] = false;
    				}
    			}else {
    				p = neighbours(i,j);
    				if(p == 3) {
    					Trans[i][j] = true;
    				}
    			}
    		}
    	}
    	for(int i = 0; i < 10; i++) {
    		for(int j = 0; j < 10; j++) {
    			World[i][j].set(Trans[i][j]);
    		}
    	}
    }
    
    public int neighbours(int x, int y) {
    	int count = 0;
		for(int m = x - 1;m <= x + 1 && m >= x - 1;m++) {
			 for(int n = y - 1;n <= y + 1 && n >= y - 1;n++) {				
				if(n == 10 && m == 10) {
					if(World[0][0].get()) {
						count++;
					}
				}else if(n == 10 && m == -1) {
					if(World[9][0].get()) {
						count++;
					}
				}else if(n == -1 && m == -1) {
					if(World[9][9].get()) {
						count++;
					}
				}else if(n == -1 && m == 10) {
					if(World[0][9].get()) {
						count++;
					}
				}else if(n == 10) {
					if(World[m][0].get()) {
						count++;
					}
				}else if(n == -1) {
					if(World[m][9].get()) {
						count++;
					}
				}else if(m == -1) {
					if(World[9][n].get()) {
						count++;
					}
				}else if(m == 10) {
					if(World[0][n].get()) {
						count++;
					}
				}else {
					if(World[m][n].get()) {
						//System.out.print("1");
						count++;
					}
				}
			}
		}
		return count;
    }
    
    public BooleanProperty cellProperty(int x, int y) {
    	return World[x][y];
    }

}
