package unsw.automata;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

/**
 * A JavaFX controller for the Conway's Game of Live Application.
 *
 * @author Robert Clifton-Everest
 *
 */
public class GameOfLifeController {
	private GameOfLife world;
	private Timeline timeline;
	private boolean load;
	
    @FXML
    private GridPane Gridpane;

    @FXML
    private Button Tick;

    @FXML
    private Button Play;
    
    public GameOfLifeController() {
    	this.timeline = new Timeline();
    	this.world = new GameOfLife();
    	this.load = false;
    }
    
    @FXML
    public void initialize() {
    	for (int i = 0; i < 10; i++) {
    		for (int j = 0; j < 10; j++) {
    			CheckBox checkbox = new CheckBox();
    			Gridpane.add(checkbox, i, j);
    		}
    	}
    }
    
    @FXML
    void handlePlay(ActionEvent event) {
    	if (load == false) {
	    	Play.setText("Stop");
	    	for (int i = 0; i < 10; i++) {
	    		for (int j = 0; j < 10; j++) {
	    			Node node = OneNode(i, j);
	    			if (node instanceof CheckBox) {
	    				CheckBox checkbox = new CheckBox();
	    				checkbox = (CheckBox) node;
		    			if (checkbox.isSelected()) {
		    				world.ensureAlive(i, j);
		    			}else {
		    				world.ensureDead(i, j);
		    			}
	    			}
	    		}
	    	}
	    	
	    	timeline.setCycleCount(Timeline.INDEFINITE);
	    	Duration time = Duration.millis(500);
	    	EventHandler<ActionEvent> handler = new EventHandler<ActionEvent>() {
	    		@Override
	    		public void handle(ActionEvent event) {
	    			handleTick(event);
	    		}
	    	};
	    	
	    	KeyFrame frame = new KeyFrame(time, handler);
	    	timeline.getKeyFrames().add(frame);
	    	load = true;
	    	
	    	timeline.play();
    	}else {
	    	if (Play.getText().equals("Play")) {
	    		Play.setText("Stop");
	    		timeline.play();
	    	}else if (Play.getText().equals("Stop")) {
	    		Play.setText("Play");
	    		timeline.stop();
	    	}
    	}
    }

    @FXML
    void handleTick(ActionEvent event) {
    	for (int i = 0; i < 10; i++) {
    		for (int j = 0; j < 10; j++) {
    			Node node = OneNode(i, j);
    			if (node instanceof CheckBox) {
    				CheckBox checkbox = new CheckBox();
    				checkbox = (CheckBox) node;
	    			if (checkbox.isSelected()) {
	    				world.ensureAlive(i, j);
	    			}else {
	    				world.ensureDead(i, j);
	    			}
    			}
    		}
    	}
    	
    	world.tick();
    	
    	for (int i = 0; i < 10; i++) {
    		for (int j = 0; j < 10; j++) {
    			Node node = OneNode(i, j);
    			if (node instanceof CheckBox) {
    				CheckBox checkbox = new CheckBox();
    				checkbox = (CheckBox) node;
	    			if (world.isAlive(i, j)) {
	    				checkbox.setSelected(true);
	    			}else {
	    				checkbox.setSelected(false);
	    			}
    			}
    		}
    	}
    }
    
    public Node OneNode(int col, int row) {
    	for (Node node: Gridpane.getChildren()) {
    		if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
    			return node;
    		}
    	}
    	return null;
    }
}


